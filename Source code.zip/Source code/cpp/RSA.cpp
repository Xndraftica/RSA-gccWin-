/*
Created by Xndraftica
Thank you for the part of the code SergiyOsadchyy (https://gist.github.com/SergiyOsadchyy/d64fe7e1f9847a4b9efaea198302b850)
*/

#include "RSA.h"

#include "h.h"

int GoToInt(char text)
{
    string alp = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxyz1234567890�����Ũ����������������������������������������������������������.,!?=+-()%";
    int inttxt;
    for(int h = 0; h <  alp.length(); h++)
    {
        if(text == alp[h])
        {
            inttxt = h;
        }
    }
    return inttxt;
}

bool chekprost(int num)
{
    bool chek = false;
    for (int i  = 2; i < sqrt(num); i++)
        {
            if(num % i == 0)
            {
                chek = true;
            }
        }
    if(num < 0)
    {
        chek = true;
    }
    return chek;
}

long int greatestCommonDivisor( unsigned long long int e, unsigned long long int t )
{
    while ( e > 0 )
    {
        long int myTemp;

        myTemp = e;
        e = t % e;
        t = myTemp;
    }

    return t;
}

long int calculateE( unsigned long long int t )
{
    // ���������� ����� ����� e ( 1 < e < t ) // ������� ������� �� ��������� ������� ������ (t)

    long int e;

    for ( e = 2; e < t; e++ )
    {
        if (greatestCommonDivisor( e, t ) == 1 )
        {
            return e;
        }
    }

    return -1;
}

RSA::RSA()
{
    srand(static_cast<unsigned int>(time(0)));
}

string RSA::GoKey()
{
    bool bo;
    int fe;
    int ff;
    do
    {
        p1 = rand();
        bo = chekprost(p1);

    } while (bo);
    do
    {
        p2 = rand();
        bo = chekprost(p2);

    } while (bo);
    n = p1 * p2;
    ret = ret + " n = " + to_string(n);
    F = (p1-1)*(p2-1);
    e = calculateE(F);
    ret = ret + " e = " + to_string(e);
    while(true)
    {
        k = k + F;
        if(k%e == 0)
        {
            d = (k/e);
            break;
        }
    }
    ret = ret + " d = " + to_string(d);

    p1 = NULL;
    p2 = NULL;
    n = NULL;
    F = NULL;
    e = NULL;
    d = NULL;
    fe = NULL;
    ff = NULL;

    return ret;
}

void RSA::Encrypt(string txt,int e, unsigned long long int  n )
{
    unsigned long long int  result, current;

    for (int i = 0; i < txt.length(); i++)
    {
        current = GoToInt(txt[i]);
        result = 1;
        for (unsigned long long int j = 0; j < e; j++ )
        {
            result = result * current;
            result = result % n;
        }
        cout << result << "~";
    }
    txt = "";
    e = NULL;
    n = NULL;
    result = NULL;
    cout << endl << "Cleaning is over." << endl;
}

void RSA::Decrypt(string txt, unsigned long long int  d, unsigned long long int  n)
{
    unsigned long long int  current;
    unsigned long long int result = 1;
    unsigned long long int numtxt[txt.length()];
    string bag = "";
    unsigned long long int gag = 0;
    unsigned long long int fi = 0;
    for(int i = 0; i < txt.length(); i++)
    {
        if(txt[i] == '~')
        {
            for(int g = fi; g < i; g++)
            {
                bag = bag + txt[g];
            }
            fi = i + 1;
            numtxt[gag] = atoi(bag.c_str());
            bag = "";
            gag++;
        }
    }
    for(int z = 0;z < gag; z++)
    {
        current = numtxt[z];
        result = 1;
        for (unsigned long long int  j = 0; j < d; j++ )
        {
            result = result * current;
            result = result % n;
        }
        cout << alp[result];
    }

    d = NULL;
    n = NULL;
    for (int u = 0; u < txt.length(); u++)
    {
        numtxt[u] = NULL;
    }

    current = NULL;
    result = NULL;
    bag = "";
    gag = NULL;
    fi = NULL;
    cout << endl << "Cleaning is over." << endl;
}
