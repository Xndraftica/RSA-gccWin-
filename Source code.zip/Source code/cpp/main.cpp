/*
Created by Xndraftica
Thank you for the part of the code SergiyOsadchyy (https://gist.github.com/SergiyOsadchyy/d64fe7e1f9847a4b9efaea198302b850)
*/

#include "h.h"

#include "RSA.h"

int main()
{
    SetConsoleCP(1251); // ���� � ������� � ��������� 1251
    SetConsoleOutputCP(1251); // ����� �� ������� � ��������� 1251. ����� ������ ����� �������� ����� ������� �� Lucida Console ��� Consolas

    RSA Q;

    int menu;
    string text;
    unsigned long long int gn;
    unsigned long long int ge;
    unsigned long long int gd;
    unsigned long long int gp1;
    unsigned long long int gp2;

    while (true)
    {
        cout << "Menu:" << endl << "1) Key generation" << endl  << "2) Encrypt" << endl  << "3) Decrypt" << endl  << "0) Exit" << endl;
        cin >> menu;
        if (menu == 1)
        {
            cout << Q.GoKey();
            Q.ret = "";
            cout << endl << "Cleaning is over." << endl;
            system("pause");
            system("cls");
        }
        else if (menu == 2)
        {
            cout << "Enter e >> ";
            cin >> ge;
            cout << endl << "Enter n >> ";
            cin >> gn;
            cout << endl << "Enter text >> ";
            cin.ignore();
            getline(cin, text);
            cout << endl;
            system("cls");
            Q.Encrypt(text,ge,gn);
            system("pause");
            system("cls");
        }
        else if (menu == 3)
        {
            cout << "Enter d >> ";
            cin >> gd;
            cout << endl << "Enter n >> ";
            cin >> gn;
            cout << endl << "Enter code >> ";
            cin.ignore();
            getline(cin, text);
            cout << endl;
            system("cls");
            Q.Decrypt(text,gd,gn);
            system("pause");
            system("cls");
        }
        else if (menu == 0)
        {break;}
        text = "";
        gn = NULL;
        ge = NULL;
        gd = NULL;
        gp1 = NULL;
        gp2 = NULL;
    }

    return 0;
}
